beta=0.5;%this is the rate of infection or probability of infection given you are adjacent to an infected node
rec=0.5;
prop=0.1;


Adjacency=[0 1 1 0 1 0 1 0 0 0; 0 0 1 1 0 0 1 1 0 0; 0 0 0 1 1 1 0 1 0 1; 0 0 0 0 1 0 1 0 1 1;0 0 0 0 0 1 0 1 0 1; 0 0 0 0 0 0 1 0 0 1; 0 0 0 0 0 0 0 1 1 1 ; 0 0 0 0 0 0 0 0 0 1; 0 0 0 0 0 0 0 0 0 0; 0 0 0 0 0 0 0 0 0 0];
G=graph(Adjacency,'upper')
names={'John', 'Julie', 'Fred', 'Sarah', 'Harry', 'Katherine', 'Johny' ,'Anna', 'Susan','Henry'}
%G.Nodes.Name= {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';%this will add a name for each node

a=plot(G);
%G.Nodes.names = {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';%this will add a name for each node

%a=plot(G);%this plots the graph
highlight(a,[1 3 4],'NodeColor','r');%this line changes the colour of the nodes specified
%B=neighbors(G,1);%this function will return all the neighbours of a particular node.

C=length(Adjacency);%this gives the total number of nodes

colours = repmat('b',C,1);%this gives our default colours for each node
colours([1 3 4])='r';%this will relabel our nodes to be their highlighted colour i.e the starting infected nodes
infected=find(colours=='r');%this returns the indexs of each infected node
time=10%this is how many time steps we want




for b= 1:time
  
  switchEdge = rand(height(G.Edges), 1) < prop
  pairs=G.Edges
  links=pairs.EndNodes
  x=links(:,1);
  y=links(:,2);
  for i=1:G.numedges
  if switchEdge(i)==0;
      
      if rand(1)>rand(1);
         c=y(i)
          x(i)=randi([1 C]);
          while x(i)==c
              x(i)=randi([1 C]);
          end
      else
          c=x(i);
          y(i)=randi([1 C]);
          while y(i)==c
              y(i)=randi([1 C]);
          end
      end
  end
  end
  pause(1)
  G=graph(x,y)
  plot(G)
  
end
  

