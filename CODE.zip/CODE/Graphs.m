G = graph([1 1],[2 4]);%this gives the initial links
e = G.Edges;%does not seem to be important
G = addedge(G,2,3);
G = addedge(G,3,4);
G = addedge(G,1,5);
G = addedge(G,3,5);
G = addedge(G,2,5);
G = addedge(G,4,5);
plot(G)