function [S,I] = sis_model(beta,gamma,N,I0,T,dt)
    % if delta = 0 we assume a model without immunity loss
    S = zeros(1,T/dt);
    S(1) = N-I0;
    I = zeros(1,T/dt);
    I(1) = I0;
    
    for tt = 1:(T/dt)-1
        % Equations of the model
    RS1=beta*I(tt)*S(tt)*dt;
    RS2=gamma*I(tt)*dt;
  
    SL=poissrnd(RS1);
    SG=poissrnd(RS2);
   
        S(tt+1) = S(tt) + -SL+SG;
        I(tt+1) = I(tt) + SL-SG;
        
        if S(tt+1)<0
            S(tt+1)=0;
        end
        if S(tt+1)>N
            S(tt+1)=N;
        end
        if I(tt+1)<0
            I(tt+1)=0;
        end
        if I(tt+1)>N
            I(tt+1)=N;
        end
       
       end
    
end
       