beta = 0.045*1.6/24; % rate of infection per act
gamma = 1/(135*4); % natural recovery rate of infection
B=0;%recruitment rate into the population
eta=0;%rate at which people leave the population
rho=2000/(742.5*4);%how often singles form pairs
IX0 = 20;
IX1=80;
IP00=35;
IP01=10;
IP11=5;
N=200;
% initial conditions
T = 8000; % period of 300 days
dt = 1/4; % time interval of 6 hours (1/4 of a day)

omega=0.67*1/(365*4);

[S,I] = sis_pair_model(B,rho,eta,omega,gamma,beta,IX0,IX1,IP00,IP01,IP11,T,dt);

A=zeros(1,2000);
omegas=zeros(1,2000);
% Calculate the model
for a=1:2000
omega2=omega*a;
omegas(a)=omega2;
[S,I] = sis_pair_model(B,rho,eta,omega2,gamma,beta,IX0,IX1,IP00,IP01,IP11,T,dt);
A(a)=I(32000);
end
max(A)
plot(omegas,A)
xlabel('Value of Omega'); ylabel('Number of infected population');