function F=Forest(n,p)
%Function creates a random forest on an n*n grid.
%There is a probability p of NO tree growth in a cell. 
%% Defining Input
%n - the size of the grid the forest will be on, each cell is a "tree"
%p - the probability (as a percentage) of tree growth in a cell
%% Input Error
if n < 1 || floor(n) ~= n %Invalid size
    error('No valid input for size. Must be a positive integer.')
end
if p < 0 || floor(p) ~= p || p>100 %Invalid probability
    error('No valid input for probability. Must be an integer value from 0 to 100')
end
%% Defining Output
%F - the matrix which model a forest, 0 is a tree, 3 is an empty space
%% Setup
colour=[0 0.5 0; 1 0 0; 0 0 0; 1 1 1]; % Creating colourmap: green, red, black, white
F=zeros(n); %Creating the forest grid
Pn=zeros(1,100);
Pn(1:(100-p))=3; %Array for probability of tree growing
%% Creating the forest
for i=1:n
    for j=1:n
        F(i,j)=F(i,j)+Pn(randi(length(Pn))); %Choosing (randomly) spots for no tree
    end
end
%% Plotting
imagesc(F) %Making the matrix F into an image
colormap(colour) %Applying the colourmap
hold on
grid off
set(gca,'yticklabel',[],'xticklabel',[],'xtick',[],'ytick',[]) %Removing ticks
end
