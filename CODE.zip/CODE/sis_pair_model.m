function [S,I] = sis_pair_model(B,rho,eta,omega,gamma,beta,IX0,IX1,IP00,IP01,IP11,T,dt)
    % if delta = 0 we assume a model without immunity loss
    
    X0=zeros(1,T/dt);
    X0(1)=IX0;
    X1=zeros(1,T/dt);
    X1(1)=IX1;
    P00=zeros(1,T/dt);
    P00(1)=IP00;
    P01=zeros(1,T/dt);
    P01(1)=IP01;
    P11=zeros(1,T/dt);
    P11(1)=IP11;
    S = zeros(1,T/dt);
    S(1) = X0(1)+2*P00(1)+P01(1);
    I = zeros(1,T/dt);
    I(1) = 0.5*P01(1)+2*P11(1)+X1(1);
    
    for tt = 1:(T/dt)-1
        % Equations of the model
        omegat=omega+omega*0.5*sin(tt/365*4);
    DX0=(B-rho*X0(tt)-eta*X0(tt)+omegat*(2*P00(tt)+P01(tt))+gamma*X1(tt)+eta*(2*P00(tt)+P01(tt)))*dt;
    DX1=(-rho*X1(tt)-eta*X1(tt)+omegat*(2*P11(tt)+P01(tt))+eta*(2*P11(tt)+P01(tt))-gamma*X1(tt))*dt;
    DP00=(0.5*rho*(X0(tt))^2/(X0(tt)+X1(tt))-omegat*P00(tt)-2*eta*P00(tt)+gamma*P01(tt))*dt;
    DP01=(rho*X0(tt)*X1(tt)/(X0(tt)+X1(tt))-omegat*P01(tt)-2*eta*P01(tt)-gamma*P01(tt)-beta*P01(tt)+2*gamma*P11(tt))*dt;
    DP11=(0.5*rho*(X1(tt))^2/(X0(tt)+X1(tt))-omegat*P11(tt)-2*eta*P11(tt)-2*gamma*P11(tt)+beta*P01(tt))*dt;
  
    X0(tt+1)=X0(tt)+DX0;
       X1(tt+1)=X1(tt)+DX1;
       P00(tt+1)=P00(tt)+DP00;
       P01(tt+1)=P01(tt)+DP01;
       P11(tt+1)=P11(tt)+DP11;
   
        S(tt+1) = X0(tt+1)+P01(tt+1)+2*P00(tt+1);
        I(tt+1) = X1(tt+1)+P01(tt+1)+2*P11(tt+1);
        
      
       
    end  
end

