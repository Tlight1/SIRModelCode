
tic
beta=0.5;%this is the rate of infection or probability of infection given you are adjacent to an infected node
rec=0.5;
prop=0.1;


Adjacency=[0 1 1 0 1 0 1 0 0 0; 0 0 1 1 0 0 1 1 0 0; 0 0 0 1 1 1 0 1 0 1; 0 0 0 0 1 0 1 0 1 1;0 0 0 0 0 1 0 1 0 1; 0 0 0 0 0 0 1 0 0 1; 0 0 0 0 0 0 0 1 1 1 ; 0 0 0 0 0 0 0 0 0 1; 0 0 0 0 0 0 0 0 0 0; 0 0 0 0 0 0 0 0 0 0];
G=graph(Adjacency,'upper')
G.Nodes.Name= {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';%this will add a name for each node

a=plot(G);
%G.Nodes.names = {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';%this will add a name for each node

%a=plot(G);%this plots the graph
highlight(a,[1 3 4],'NodeColor','r');%this line changes the colour of the nodes specified
%B=neighbors(G,1);%this function will return all the neighbours of a particular node.

C=length(Adjacency);%this gives the total number of nodes

colours = repmat('b',C,1);%this gives our default colours for each node
colours([1 3 4])='r';%this will relabel our nodes to be their highlighted colour i.e the starting infected nodes
infected=find(colours=='r');%this returns the indexs of each infected node
possinf=[];
time=0;
S=[];
I=[];
R=[];
while length(infected)>0
infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(time+1)=length(infected)
R(time+1)=length(recovered)
S(time+1)=C-length(recovered)-length(infected)
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end

possinf=unique(possinf.','rows');
possinf=unique(possinf.','rows');%unsure why but it require me to run it twice to remove duplicates

for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end

for i=1:length(recovered)
    possinf(possinf==recovered(i))=[];%this elimates any chance of a recovered node
    
end


for i=1:length(possinf)
    if rand<beta%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end

for i=1:length(infected)%this for loop checks to see if an infected node recovers
    if rand<rec
        colours(infected(i))='g';
        highlight(a,infected(i),'Nodecolor','g')
    end
 pause(0.5)
end
time=time+1;
end
tt=0:time-1
figure
plot(tt,S,'b',tt,I,'r',tt,R,'g','LineWidth',2); grid on;
xlabel('Days'); ylabel('Number of individuals');
legend('S','I','R');

toc

for source=1:height(G.Edges)    
    switchEdge = rand(height(G.Edges), 1) < prop;
    
    newTargets = rand(C, 1);
    newTargets(source) = 0;
    newTargets(s(t==source)) = 0;
    newTargets(t(source, ~switchEdge)) = 0;
    
    [~, ind] = sort(newTargets, 'descend');
    t(source, switchEdge) = ind(1:nnz(switchEdge));
end