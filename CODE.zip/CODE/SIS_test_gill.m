% Model parameters
beta = 3.3*10^-3; % rate of infection
gamma = 0.3; % rate of Infectious population going to susceptible
N = 200; % Total population N = S + I 
I0 = 10; % initial number of infected
T = 100; % period of 300 days
dt = 1/4; % time interval of 6 hours (1/4 of a day)
fprintf('Value of parameter R0 is %.2f',N*beta/gamma)

% Calculate the model
[S,I] = sis_model_gill(beta,gamma,N,I0,T,dt);
% Plots that display the epidemic outbreak
Sav=Sav+S;
Iav=Iav+I;
sim=sim+1
tt = 0:dt:T-dt;
% Curve
plot(tt,S,'b',tt,I,'r','LineWidth',2); grid on;
xlabel('Days'); ylabel('Number of individuals');
legend('S','I');