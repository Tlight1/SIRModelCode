% Model parameters
beta = 0.045*1.6/(200*24); % rate of infection
gamma = 1/(135*4); % rate of Infectious population going to susceptible
N = 200; % Total population N = S + I 
I0 = 100; % initial number of infected
T = 5000; % period of 300 days
dt = 1/4; % time interval of 6 hours (1/4 of a day)
fprintf('Value of parameter R0 is %.2f',N*beta/gamma)

% Calculate the model
[S,I] = sis_model(beta,gamma,N,I0,T,dt);
% Plots that display the epidemic outbreak
tt = 0:dt:T-dt;
% Curve
plot(tt,S,'b',tt,I,'r','LineWidth',2); grid on;
xlabel('Days'); ylabel('Number of individuals');
legend('S','I');

