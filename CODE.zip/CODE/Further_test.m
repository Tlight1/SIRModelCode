beta=0.15;%this is the chance of an infection given one sexual contact
rec=0.5;
prop=0.1;


Adjacency=[0 1 1 0 1 0 1 0 0 0; 0 0 1 1 0 0 1 1 0 0; 0 0 0 1 1 1 0 1 0 1; 0 0 0 0 1 0 1 0 1 1;0 0 0 0 0 1 0 1 0 1; 0 0 0 0 0 0 1 0 0 1; 0 0 0 0 0 0 0 1 1 1 ; 0 0 0 0 0 0 0 0 0 1; 0 0 0 0 0 0 0 0 0 0; 0 0 0 0 0 0 0 0 0 0];
G=graph(Adjacency,'upper');
names={'John', 'Julie', 'Fred', 'Sarah', 'Harry', 'Katherine', 'Johny' ,'Anna', 'Susan','Henry'};
%G.Nodes.Name= {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';%this will add a name for each node

a=plot(G);
%G.Nodes.names = {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';%this will add a name for each node

%a=plot(G);%this plots the graph
highlight(a,[1 3 4],'NodeColor','r');%this line changes the colour of the nodes specified
%B=neighbors(G,1);%this function will return all the neighbours of a particular node.

C=length(Adjacency);%this gives the total number of nodes

colours = repmat('b',C,1);%this gives our default colours for each node
colours([1 3 4])='r';%this will relabel our nodes to be their highlighted colour i.e the starting infected nodes
infected=find(colours=='r');%this returns the indexs of each infected node
possinf=[];
time=0;
S=[];
I=[];
R=[];
time=0;%this is how many time steps we want
while length(infected)>0
infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(time+1)=length(infected);
R(time+1)=length(recovered);
S(time+1)=C-length(recovered)-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end


for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end

for i=1:length(recovered)
    possinf(possinf==recovered(i))=[];%this elimates any chance of a recovered node
    
end

tot=possinf;
possinf=unique(possinf);


for i=1:length(possinf)
    encounter=sum(tot==possinf(i));
    if rand<1-(1-beta)^encounter%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end

for i=1:length(infected)%this for loop checks to see if an infected node recovers
    if rand<rec
        colours(infected(i))='g';
        highlight(a,infected(i),'Nodecolor','g')
    end
 pause(0.05)
end

  
%   switchEdge = rand(height(G.Edges), 1) < prop;
%   pairs=G.Edges;
%   links=pairs.EndNodes;
%   x=links(:,1);
%   y=links(:,2);
%   for i=1:G.numedges
%   if switchEdge(i)==0
%       
%       if rand(1)>rand(1)
%          c=y(i);
%           x(i)=randi([1 C]);
%           while x(i)==c
%               x(i)=randi([1 C]);
%           end
%       else
%           c=x(i);
%           y(i)=randi([1 C]);
%           while y(i)==c
%               y(i)=randi([1 C]);
%           end
%       end
%   end
%   end
%   pause(0.1)
%   G=graph(x,y);
%   a=plot(G);
%   highlight(a,find(colours=='g'),'Nodecolor','g')
%   highlight(a,find(colours=='r'),'Nodecolor','r')

time=time+1;
end

G.Nodes.Name = {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';
a=plot(G);
  highlight(a,find(colours=='g'),'Nodecolor','g')
  highlight(a,find(colours=='r'),'Nodecolor','r')
figure
tt=0:time-1;
plot(tt,S,'b',tt,I,'r',tt,R,'g','LineWidth',2); grid on;
xlabel('Days'); ylabel('Number of individuals');
legend('S','I','R');

