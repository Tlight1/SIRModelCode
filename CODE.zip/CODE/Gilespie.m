

dt=1/4;
beta=3.3*10^-3;
gamma=0.2;
T=100;
S = zeros(1,T/dt);
S(1)=190;
I = zeros(1,T/dt);
I(1)=10;
R = zeros(1,T/dt);
N=S(1)+I(1);

for tt = 1:(T/dt)-1
    RS=beta*I(tt)*S(tt)*dt;
    dI1 = (beta*I(tt)*S(tt))*dt;
    dI2 = (gamma*I(tt))* dt;
    dR = (gamma*I(tt))*dt;
        S(tt+1) = S(tt) + -poissrnd(RS);
        I(tt+1) = I(tt) + poissrnd(dI1)-poissrnd(dI2);
        R(tt+1) = R(tt) + poissrnd(dR);
        if S(tt+1)<0
            S(tt+1)=0
        end
        if I(tt+1)<0
            I(tt+1)=0
        end
        if R(tt+1)>N
            R(tt+1)=N
        end
end
tt = 0:dt:T-dt;
plot(tt,I,'r','LineWidth',1); grid on;
xlabel('Days'); ylabel('Number of individuals');
legend('S','I','R');
hold on
CS=CS+S;
CI=CI+I;
CR=CR+R;
sim=sim+1
    