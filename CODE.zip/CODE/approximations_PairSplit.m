beta = 0.045*1.6/24; % rate of infection per act
gamma = 1/(135*4); % natural recovery rate of infection
B=0;%recruitment rate into the population
eta=0;%rate at which people leave the population
rho=2000/(742.5*4);%how often singles form pairs
IX0 = 20;
IX1=80;
IP00=35;
IP01=10;
IP11=5;
N=200;
% initial conditions
T = 8000; % period of 300 days
dt = 1/4; % time interval of 6 hours (1/4 of a day)

omega=0.67*1/(365*4);
omega2=0.67*500/(365*4);
[S,I] = sis_pair_model(B,rho,eta,omega,gamma,beta,IX0,IX1,IP00,IP01,IP11,T,dt);
[S,I2] = sis_pair_model(B,rho,eta,omega2,gamma,beta,IX0,IX1,IP00,IP01,IP11,T,dt);

% Calculate the model
for a=1:3000
    if I2(32000)>I(32000)
        omega=(omega+omega2)/2
    else
        omega2=(omega+omega2)/2
    end
[S,I] = sis_pair_model(B,rho,eta,omega,gamma,beta,IX0,IX1,IP00,IP01,IP11,T,dt);
[S,I2] = sis_pair_model(B,rho,eta,omega2,gamma,beta,IX0,IX1,IP00,IP01,IP11,T,dt);
end
tt = 0:dt:T-dt;
% Curve
plot(tt,S,'b',tt,I2,'r','LineWidth',2); grid on;
xlabel('Days'); ylabel('Number of individuals');
legend('S','I');
