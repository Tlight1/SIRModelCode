function [S,I] = sis_model(beta,gamma,N,I0,T,dt)
    % if delta = 0 we assume a model without immunity loss
    S = zeros(1,T/dt);
    S(1) = N-I0;
    I = zeros(1,T/dt);
    I(1) = I0;
    for tt = 1:(T/dt)-1
        % Equations of the model
        dS = (-beta*I(tt)*S(tt)+gamma*I(tt))*dt;
        dI = (beta*I(tt)*S(tt) - gamma*I(tt)) * dt;
       
        S(tt+1) = S(tt) + dS;
        I(tt+1) = I(tt) + dI;
    end
end
