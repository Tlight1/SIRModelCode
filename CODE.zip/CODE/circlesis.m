beta=0.5;%this is the chance of an infection given one sexual contact
rec=0.4;
prop=0.1;

x=[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30]
y=[2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 1]
G=graph(x,y)
a=plot(G);
%G.Nodes.names = {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';%this will add a name for each node

%a=plot(G);%this plots the graph
highlight(a,[1 4 10 14 17],'NodeColor','r');%this line changes the colour of the nodes specified
%B=neighbors(G,1);%this function will return all the neighbours of a particular node.

C=length(x);%this gives the total number of nodes

colours = repmat('b',C,1);%this gives our default colours for each node
colours([1 3 4])='r';%this will relabel our nodes to be their highlighted colour i.e the starting infected nodes
infected=find(colours=='r');%this returns the indexs of each infected node
possinf=[];
time=0;
S=[];
I=[];

time=0;%this is how many time steps we want
while time<300
infected=find(colours=='r');%this returns the indexs of each infected node
possinf=[];
I(time+1)=length(infected);
S(time+1)=C-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end


for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end


tot=possinf;
possinf=unique(possinf);


for i=1:length(possinf)
    encounter=sum(tot==possinf(i));
    if rand<1-(1-beta)^encounter%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end

for i=1:length(infected)%this for loop checks to see if an infected node recovers
    if rand<rec
        colours(infected(i))='b';
        highlight(a,infected(i),'Nodecolor','b')
    end
 pause(0.01)
end

  
%  switchEdge = rand(height(G.Edges), 1) < prop;
%  pairs=G.Edges;
%   links=pairs.EndNodes;
%   x=links(:,1);
%   y=links(:,2);
%   for i=1:G.numedges
%   if switchEdge(i)==0
%       
%      if rand(1)>rand(1)
%         c=y(i);
%          x(i)=randi([1 C]);
%          while x(i)==c
%              x(i)=randi([1 C]);
%          end
%       else
%          c=x(i);
%          y(i)=randi([1 C]);
%          while y(i)==c
%              y(i)=randi([1 C]);
%           end
%       end
%   end
%   end
  pause(0.01)
%   G=graph(x,y);
%   a=plot(G);
%   highlight(a,find(colours=='g'),'Nodecolor','g')
%   highlight(a,find(colours=='r'),'Nodecolor','r')

time=time+1;
end

% G.Nodes.Name = {'John' 'Julie' 'Fred' 'Sarah' 'Harry' 'Katherine' 'Johny' 'Anna' 'Susan' 'Henry'}';
% a=plot(G);
%   highlight(a,find(colours=='r'),'Nodecolor','r')
% figure
tt=0:time-1;
plot(tt,S,'b',tt,I,'r','LineWidth',2); grid on;
xlabel('Days'); ylabel('Number of individuals');
legend('S','I');
