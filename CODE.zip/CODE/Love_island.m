beta=0.5;%this is the rate of infection or probability of infection given you are adjacent to an infected node

G = graph([1 3], [2 4]);%this gives the initial links
e = G.Edges;%does not seem to be important
G = addnode(G,23);%this adds nodes without any links
G = addedge(G,5,6);%this adds an edge between two  existing nodes
G = addedge(G,7,8);
G = addedge(G,11,12);
G = addedge(G,9,10);


G.Nodes.Name = {'Hugo' 'Sharon' 'Toby' 'Kaz' 'Aaron' 'Shannon' 'Faye' 'Brad' 'Jake' 'Liberty' 'Aaron2' 'Chloe' 'Rachel' 'Liam' 'Lucinda' 'Millie' 'Teddy' 'AJ' 'Danny' 'Tyler' 'Abigal' 'Matthew' 'Sam' 'Dale' 'Amy' 'Mary' 'Clarisse'}';%this will add a name for each node

a=plot(G);%this plots the graph
infectionI=[1,3,10,16,7]
highlight(a,infectionI  ,'NodeColor','r');%this line changes the colour of the nodes specified

B=neighbors(G,1);%this function will return all the neighbours of a particular node.

C=numnodes(G);%this gives the total number of nodes

colours = repmat('b',C,1);%this gives our default colours for each node
colours(infectionI(1))='r';%this will relabel our nodes to be their highlighted colour i.e the starting infected nodes
infected=find(colours=='r');%this returns the indexs of each infected node
possinf=[];
time=0;
S=[];
I=[];

%week zero
infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(1)=length(infected);
S(1)=C-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end

possinf=unique(possinf.','rows');
possinf=unique(possinf.','rows');%unsure why but it require me to run it twice to remove duplicates

for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end


for i=1:length(possinf)
    if rand<beta%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end
%week one
G = graph([3 5], [4 6]);%this gives the initial links
e = G.Edges;%does not seem to be important
G = addnode(G,21);%this adds nodes without any links
G = addedge(G,9,10);
G = addedge(G,14,7);
G = addedge(G,1,12);
G = addedge(G,8,13);

G.Nodes.Name = {'Hugo' 'Sharon' 'Toby' 'Kaz' 'Aaron' 'Shannon' 'Faye' 'Brad' 'Jake' 'Liberty' 'Aaron2' 'Chloe' 'Rachel' 'Liam' 'Lucinda' 'Millie' 'Teddy' 'AJ' 'Danny' 'Tyler' 'Abigal' 'Matthew' 'Sam' 'Dale' 'Amy' 'Mary' 'Clarisse'}';%this will add a name for each node

a=plot(G);%this plots the graph



highlight(a,transpose(find(colours=='r')),'NodeColor','r')

infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(2)=length(infected);
S(2)=C-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end

possinf=unique(possinf.','rows');
possinf=unique(possinf.','rows');%unsure why but it require me to run it twice to remove duplicates

for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end


for i=1:length(possinf)
    if rand<beta%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end

%week two
G = graph([5 9], [4 10]);%this gives the initial links
e = G.Edges;%does not seem to be important
G = addnode(G,17);%this adds nodes without any links
G = addedge(G,15,8);
G = addedge(G,14,16);
G = addedge(G,1,2);
G = addedge(G,3,12);
G = addedge(G,17,7);

G.Nodes.Name = {'Hugo' 'Sharon' 'Toby' 'Kaz' 'Aaron' 'Shannon' 'Faye' 'Brad' 'Jake' 'Liberty' 'Aaron2' 'Chloe' 'Rachel' 'Liam' 'Lucinda' 'Millie' 'Teddy' 'AJ' 'Danny' 'Tyler' 'Abigal' 'Matthew' 'Sam' 'Dale' 'Amy' 'Mary' 'Clarisse'}';%this will add a name for each node

a=plot(G);%this plots the graph



highlight(a,transpose(find(colours=='r')),'NodeColor','r')

infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(3)=length(infected);
S(3)=C-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end

possinf=unique(possinf.','rows');
possinf=unique(possinf.','rows');%unsure why but it require me to run it twice to remove duplicates

for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end


for i=1:length(possinf)
    if rand<beta%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end

%week three
G = graph([18 19], [1 15]);%this gives the initial links
e = G.Edges;%does not seem to be important
G = addnode(G,8);%this adds nodes without any links
G = addedge(G,5,4);
G = addedge(G,12,3);
G = addedge(G,9,10);
G = addedge(G,17,7);
G = addedge(G,14,16);

G.Nodes.Name = {'Hugo' 'Sharon' 'Toby' 'Kaz' 'Aaron' 'Shannon' 'Faye' 'Brad' 'Jake' 'Liberty' 'Aaron2' 'Chloe' 'Rachel' 'Liam' 'Lucinda' 'Millie' 'Teddy' 'AJ' 'Danny' 'Tyler' 'Abigal' 'Matthew' 'Sam' 'Dale' 'Amy' 'Mary' 'Clarisse'}';%this will add a name for each node

a=plot(G);%this plots the graph



highlight(a,transpose(find(colours=='r')),'NodeColor','r')

infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(4)=length(infected);
S(4)=C-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end

possinf=unique(possinf.','rows');
possinf=unique(possinf.','rows');%unsure why but it require me to run it twice to remove duplicates

for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end


for i=1:length(possinf)
    if rand<beta%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end

%week four
G = graph([5 1], [15 12]);%this gives the initial links
e = G.Edges;%does not seem to be important
G = addnode(G,12);%this adds nodes without any links
G = addedge(G,20,4);
G = addedge(G,21,3);
G = addedge(G,9,10);
G = addedge(G,7,17);
G = addedge(G,14,16);

G.Nodes.Name = {'Hugo' 'Sharon' 'Toby' 'Kaz' 'Aaron' 'Shannon' 'Faye' 'Brad' 'Jake' 'Liberty' 'Aaron2' 'Chloe' 'Rachel' 'Liam' 'Lucinda' 'Millie' 'Teddy' 'AJ' 'Danny' 'Tyler' 'Abigal' 'Matthew' 'Sam' 'Dale' 'Amy' 'Mary' 'Clarisse'}';%this will add a name for each node

a=plot(G);%this plots the graph



highlight(a,transpose(find(colours=='r')),'NodeColor','r')

infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(5)=length(infected);
S(5)=C-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end

possinf=unique(possinf.','rows');
possinf=unique(possinf.','rows');%unsure why but it require me to run it twice to remove duplicates

for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end


for i=1:length(possinf)
    if rand<beta%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end

%week five
G = graph([22 23], [4 7]);%this gives the initial links
e = G.Edges;%does not seem to be important
G = addnode(G,4);%this adds nodes without any links
G = addedge(G,24,12);
G = addedge(G,1,25);
G = addedge(G,3,26);
G = addedge(G,9,10);
G = addedge(G,14,27);

G.Nodes.Name = {'Hugo' 'Sharon' 'Toby' 'Kaz' 'Aaron' 'Shannon' 'Faye' 'Brad' 'Jake' 'Liberty' 'Aaron2' 'Chloe' 'Rachel' 'Liam' 'Lucinda' 'Millie' 'Teddy' 'AJ' 'Danny' 'Tyler' 'Abigal' 'Matthew' 'Sam' 'Dale' 'Amy' 'Mary' 'Clarisse'}';%this will add a name for each node

a=plot(G);%this plots the graph



highlight(a,transpose(find(colours=='r')),'NodeColor','r')

infected=find(colours=='r');%this returns the indexs of each infected node
recovered=find(colours=='g');
possinf=[];
I(6)=length(infected);
S(6)=C-length(infected);
for i= 1:length(infected)
    possinf=[neighbors(G,infected(i)); possinf];
   
end

possinf=unique(possinf.','rows');
possinf=unique(possinf.','rows');%unsure why but it require me to run it twice to remove duplicates

for i=1:length(infected)
    possinf(possinf==infected(i))=[];%this elimates any links to an already infected node
    
end


for i=1:length(possinf)
    if rand<beta%this is testing if we get infected
        colours(possinf(i))='r';%
        highlight(a,possinf(i),'NodeColor','r')
    end
end
Test=Test+1
Sav=S+Sav
Iav=I+Iav
averageS=Sav/Test
averageI=Iav/Test
plot(tt,averageS,'b',tt,averageI,'r','LineWidth',2); grid on;
xlabel('Weeks'); ylabel('Number of individuals');
legend('S','I');